(function(){"use strict";try{if(typeof document!="undefined"){var e=document.createElement("style");e.id="lowcoder-comp-template-demos-0.0.2",e.appendChild(document.createTextNode("")),document.head.appendChild(e)}}catch(d){console.error("vite-plugin-css-injected-by-js",d)}})();
var _ = Object.defineProperty, z = Object.defineProperties;
var R = Object.getOwnPropertyDescriptors;
var S = Object.getOwnPropertySymbols;
var I = Object.prototype.hasOwnProperty, P = Object.prototype.propertyIsEnumerable;
var k = (e, i, n) => i in e ? _(e, i, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[i] = n, g = (e, i) => {
  for (var n in i || (i = {}))
    I.call(i, n) && k(e, n, i[n]);
  if (S)
    for (var n of S(i))
      P.call(i, n) && k(e, n, i[n]);
  return e;
}, p = (e, i) => z(e, R(i));
var C = { exports: {} }, f = {};
const T = $react;
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var D = T, A = Symbol.for("react.element"), $ = Symbol.for("react.fragment"), O = Object.prototype.hasOwnProperty, B = D.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner, M = { key: !0, ref: !0, __self: !0, __source: !0 };
function H(e, i, n) {
  var a, r = {}, l = null, d = null;
  n !== void 0 && (l = "" + n), i.key !== void 0 && (l = "" + i.key), i.ref !== void 0 && (d = i.ref);
  for (a in i)
    O.call(i, a) && !M.hasOwnProperty(a) && (r[a] = i[a]);
  if (e && e.defaultProps)
    for (a in i = e.defaultProps, i)
      r[a] === void 0 && (r[a] = i[a]);
  return { $$typeof: A, type: e, key: l, ref: d, props: r, _owner: B.current };
}
f.Fragment = $;
f.jsx = H;
f.jsxs = H;
C.exports = f;
var v = C.exports;
const w = v.Fragment, t = v.jsx, o = v.jsxs;
function c(e) {
  var r, l;
  const i = (r = e.containers[e.zoneId]) == null ? void 0 : r.children;
  if (!i)
    return null;
  const n = e.hint ? /* @__PURE__ */ t($lowcoder_sdk.ContainerPlaceholder, {
    children: e.hint
  }) : $lowcoder_sdk.HintPlaceHolder, a = (d) => {
    d.stopPropagation(), document.dispatchEvent(new MouseEvent("mousedown"));
  };
  return /* @__PURE__ */ t("div", {
    "data-lowcoder-dropzone": e.zoneId,
    draggable: !1,
    onMouseDown: a,
    style: {
      width: "100%",
      height: e.autoHeight ? "auto" : "100%",
      minHeight: e.minHeight,
      margin: 0,
      padding: 0,
      overflow: e.autoHeight ? "visible" : "hidden"
    },
    children: /* @__PURE__ */ t($lowcoder_sdk.InnerGrid, {
      layout: i.layout.getView(),
      items: $lowcoder_sdk.gridItemCompToGridItems(i.items.getView()),
      positionParams: i.positionParams.getView(),
      dispatch: $lowcoder_sdk.wrapDispatch($lowcoder_sdk.wrapDispatch(e.dispatch, "containers"), e.zoneId),
      autoHeight: e.autoHeight,
      horizontalGridCells: e.horizontalGridCells,
      emptyRows: (l = e.emptyRows) != null ? l : 15,
      minHeight: e.minHeight,
      containerPadding: e.containerPadding,
      hintPlaceholder: n,
      showName: e.showName,
      overflow: e.autoHeight ? "visible" : "hidden"
    })
  });
}
function j(e, i, n) {
  var a;
  return n == null ? (a = e[i]) != null ? a : Object.values(e)[0] : Object.values(e).find((r) => r.realSimpleContainer(n));
}
function V(e) {
  return $lowcoder_sdk.mergeCompTrees(Object.values(e).map((i) => i.getCompTree()));
}
function W(e, i, n) {
  for (const a of Object.values(i)) {
    const r = a.findContainer(n);
    if (r)
      return r === a ? e : r;
  }
}
function E(e, i, n) {
  const a = {};
  return Object.keys(i).forEach((r) => {
    a[r] = i[r].getPasteValue(n);
  }), p(g({}, e), { containers: a });
}
function h(e, i, n) {
  const a = {
    autoHeight: $lowcoder_sdk.withDefault($lowcoder_sdk.AutoHeightControl, "auto"),
    containers: $lowcoder_sdk.withDefault($lowcoder_sdk.sameTypeMap($lowcoder_sdk.SimpleContainerComp), i)
  }, r = new $lowcoder_sdk.UICompBuilder(a, (d, s) => /* @__PURE__ */ t(e, p(g({}, d), {
    dispatch: s
  }))).setPropertyViewFn(() => null).build();
  class l extends r {
    realSimpleContainer(s) {
      return j(this.children.containers.children, n, s);
    }
    getCompTree() {
      return V(this.children.containers.getView());
    }
    findContainer(s) {
      return W(this, this.children.containers.getView(), s);
    }
    getPasteValue(s) {
      return E(this.toJsonValue(), this.children.containers.getView(), s);
    }
    autoHeight() {
      return this.children.autoHeight.getView();
    }
  }
  return $lowcoder_sdk.withExposingConfigs(l, [$lowcoder_sdk.NameConfigHidden]);
}
const G = [{
  label: "Total Users",
  value: "12,847",
  accent: "#4361ee"
}, {
  label: "Revenue",
  value: "$48.2K",
  accent: "#2ec4b6"
}, {
  label: "Orders",
  value: "1,024",
  accent: "#ff6b6b"
}, {
  label: "Conversion",
  value: "3.24%",
  accent: "#ffd166"
}];
function F() {
  return /* @__PURE__ */ o(w, {
    children: [/* @__PURE__ */ o("header", {
      style: {
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        padding: "0 24px",
        height: 56,
        background: "#1a1a2e",
        color: "#fff",
        flexShrink: 0
      },
      children: [/* @__PURE__ */ t("div", {
        style: {
          fontSize: 18,
          fontWeight: 700
        },
        children: "My Dashboard"
      }), /* @__PURE__ */ t("nav", {
        style: {
          display: "flex",
          gap: 24,
          fontSize: 14,
          opacity: 0.85
        },
        children: ["Overview", "Analytics", "Reports", "Settings"].map((e) => /* @__PURE__ */ t("span", {
          children: e
        }, e))
      })]
    }), /* @__PURE__ */ t("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "repeat(4, 1fr)",
        gap: 16,
        padding: "20px 24px",
        flexShrink: 0
      },
      children: G.map((e) => /* @__PURE__ */ o("div", {
        style: {
          background: "#fff",
          borderRadius: 10,
          padding: "18px 20px",
          boxShadow: "0 1px 3px rgba(0,0,0,0.06)",
          borderLeft: `4px solid ${e.accent}`
        },
        children: [/* @__PURE__ */ t("div", {
          style: {
            fontSize: 12,
            color: "#8c8c8c",
            textTransform: "uppercase",
            letterSpacing: "0.5px",
            marginBottom: 6
          },
          children: e.label
        }), /* @__PURE__ */ t("div", {
          style: {
            fontSize: 26,
            fontWeight: 700,
            color: "#1a1a2e"
          },
          children: e.value
        })]
      }, e.label))
    })]
  });
}
const u = "main_content";
function N(e) {
  return /* @__PURE__ */ o("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      width: "100%",
      height: e.autoHeight ? "auto" : "100%",
      minHeight: e.autoHeight ? 640 : void 0,
      background: "#f0f2f5",
      fontFamily: "Inter, system-ui, sans-serif",
      overflow: "hidden"
    },
    children: [/* @__PURE__ */ t(F, {}), /* @__PURE__ */ t("div", {
      style: {
        flex: 1,
        padding: "0 24px 24px",
        minHeight: 300
      },
      children: /* @__PURE__ */ t("div", {
        style: {
          background: "#fff",
          borderRadius: 10,
          boxShadow: "0 1px 3px rgba(0,0,0,0.06)",
          height: "100%",
          minHeight: 300,
          overflow: "hidden"
        },
        children: /* @__PURE__ */ t(c, {
          containers: e.containers,
          dispatch: e.dispatch,
          zoneId: u,
          autoHeight: !0,
          horizontalGridCells: 12,
          emptyRows: 20,
          minHeight: "300px",
          containerPadding: [16, 16],
          hint: "Drop charts, tables, or widgets here"
        })
      })
    })]
  });
}
const L = h(N, {
  [u]: {
    layout: {},
    items: {}
  }
}, u);
function U() {
  return /* @__PURE__ */ t(w, {
    children: /* @__PURE__ */ o("section", {
      style: {
        background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
        color: "#fff",
        padding: "60px 48px",
        textAlign: "center",
        flexShrink: 0
      },
      children: [/* @__PURE__ */ t("h1", {
        style: {
          margin: "0 0 16px",
          fontSize: 42,
          fontWeight: 800,
          letterSpacing: -1
        },
        children: "Build Something Amazing"
      }), /* @__PURE__ */ t("p", {
        style: {
          margin: "0 auto 32px",
          maxWidth: 600,
          fontSize: 18,
          opacity: 0.9,
          lineHeight: 1.6
        },
        children: "A powerful platform to create, deploy, and scale your applications with ease."
      }), /* @__PURE__ */ t("div", {
        style: {
          display: "inline-block",
          background: "#fff",
          color: "#667eea",
          padding: "14px 36px",
          borderRadius: 8,
          fontWeight: 600,
          fontSize: 16
        },
        children: "Get Started Free"
      })]
    })
  });
}
function Y() {
  return /* @__PURE__ */ t("footer", {
    style: {
      background: "#1a1a2e",
      color: "#fff",
      padding: "32px 48px",
      flexShrink: 0
    },
    children: /* @__PURE__ */ o("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "2fr 1fr 1fr 1fr",
        gap: 32
      },
      children: [/* @__PURE__ */ o("div", {
        children: [/* @__PURE__ */ t("div", {
          style: {
            fontSize: 20,
            fontWeight: 700,
            marginBottom: 8
          },
          children: "YourBrand"
        }), /* @__PURE__ */ t("p", {
          style: {
            fontSize: 13,
            opacity: 0.6,
            margin: 0,
            lineHeight: 1.6
          },
          children: "Making the world a better place through quality software and design."
        })]
      }), [{
        title: "Product",
        links: ["Features", "Pricing", "Docs"]
      }, {
        title: "Company",
        links: ["About", "Blog", "Careers"]
      }, {
        title: "Support",
        links: ["Help", "Contact", "Status"]
      }].map((e) => /* @__PURE__ */ o("div", {
        children: [/* @__PURE__ */ t("div", {
          style: {
            fontSize: 13,
            fontWeight: 600,
            textTransform: "uppercase",
            letterSpacing: "0.5px",
            marginBottom: 12,
            opacity: 0.8
          },
          children: e.title
        }), e.links.map((i) => /* @__PURE__ */ t("div", {
          style: {
            fontSize: 13,
            opacity: 0.5,
            marginBottom: 8
          },
          children: i
        }, i))]
      }, e.title))]
    })
  });
}
const m = "main_content";
function Z(e) {
  return /* @__PURE__ */ o("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      width: "100%",
      height: e.autoHeight ? "auto" : "100%",
      minHeight: e.autoHeight ? 720 : void 0,
      background: "#fff",
      fontFamily: "Inter, system-ui, sans-serif"
    },
    children: [/* @__PURE__ */ t(U, {}), /* @__PURE__ */ t("div", {
      style: {
        flex: 1,
        minHeight: 250
      },
      children: /* @__PURE__ */ t(c, {
        containers: e.containers,
        dispatch: e.dispatch,
        zoneId: m,
        autoHeight: !0,
        horizontalGridCells: 12,
        emptyRows: 18,
        minHeight: "250px",
        containerPadding: [32, 32],
        hint: "Drop content sections here"
      })
    }), /* @__PURE__ */ t(Y, {})]
  });
}
const q = h(Z, {
  [m]: {
    layout: {},
    items: {}
  }
}, m), J = [{
  icon: "📊",
  label: "Dashboard",
  active: !0
}, {
  icon: "👥",
  label: "Users"
}, {
  icon: "📦",
  label: "Products"
}, {
  icon: "📈",
  label: "Analytics"
}, {
  icon: "💬",
  label: "Messages"
}, {
  icon: "⚙️",
  label: "Settings"
}];
function K() {
  const [e, i] = $react.useState(!1);
  return /* @__PURE__ */ o("aside", {
    style: {
      width: e ? 60 : 240,
      background: "#1a1a2e",
      color: "#fff",
      display: "flex",
      flexDirection: "column",
      flexShrink: 0,
      transition: "width 0.2s ease",
      overflow: "hidden"
    },
    children: [/* @__PURE__ */ o("div", {
      style: {
        padding: e ? "20px 12px" : "20px 20px",
        borderBottom: "1px solid rgba(255,255,255,0.08)",
        display: "flex",
        alignItems: "center",
        gap: 12
      },
      children: [/* @__PURE__ */ t("div", {
        style: {
          width: 32,
          height: 32,
          borderRadius: 8,
          background: "#4361ee",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontWeight: 800,
          fontSize: 14,
          flexShrink: 0
        },
        children: "A"
      }), !e && /* @__PURE__ */ t("div", {
        style: {
          fontSize: 16,
          fontWeight: 700
        },
        children: "My App"
      })]
    }), /* @__PURE__ */ o("nav", {
      style: {
        padding: "16px 0",
        flex: 1
      },
      children: [/* @__PURE__ */ t("div", {
        style: {
          fontSize: 10,
          textTransform: "uppercase",
          letterSpacing: 1,
          color: "rgba(255,255,255,0.35)",
          padding: e ? "0 12px" : "0 20px",
          marginBottom: 8
        },
        children: e ? "•" : "Navigation"
      }), J.map((n) => /* @__PURE__ */ o("div", {
        style: {
          display: "flex",
          alignItems: "center",
          gap: 12,
          padding: e ? "10px 18px" : "10px 20px",
          margin: "2px 8px",
          borderRadius: 8,
          fontSize: 14,
          background: n.active ? "#4361ee" : "transparent",
          opacity: n.active ? 1 : 0.65
        },
        children: [/* @__PURE__ */ t("span", {
          style: {
            width: 20,
            textAlign: "center"
          },
          children: n.icon
        }), !e && n.label]
      }, n.label))]
    }), /* @__PURE__ */ t("button", {
      type: "button",
      onClick: () => i(!e),
      onMouseDown: (n) => n.stopPropagation(),
      style: {
        padding: "16px 20px",
        border: "none",
        borderTop: "1px solid rgba(255,255,255,0.08)",
        background: "transparent",
        color: "#fff",
        fontSize: 13,
        opacity: 0.5,
        cursor: "pointer",
        textAlign: "left"
      },
      children: e ? "→" : "← Collapse"
    })]
  });
}
const x = "main_content";
function Q(e) {
  return /* @__PURE__ */ o("div", {
    style: {
      display: "flex",
      width: "100%",
      height: e.autoHeight ? "auto" : "100%",
      minHeight: e.autoHeight ? 600 : void 0,
      fontFamily: "Inter, system-ui, sans-serif",
      overflow: "hidden"
    },
    children: [/* @__PURE__ */ t(K, {}), /* @__PURE__ */ o("main", {
      style: {
        flex: 1,
        minWidth: 0,
        display: "flex",
        flexDirection: "column",
        background: "#f5f6fa"
      },
      children: [/* @__PURE__ */ t("div", {
        style: {
          padding: "20px 28px",
          borderBottom: "1px solid #e8e8e8",
          background: "#fff"
        },
        children: /* @__PURE__ */ t("h2", {
          style: {
            margin: 0,
            fontSize: 22,
            fontWeight: 700,
            color: "#1a1a2e"
          },
          children: "Dashboard"
        })
      }), /* @__PURE__ */ t("div", {
        style: {
          flex: 1,
          minHeight: 300
        },
        children: /* @__PURE__ */ t(c, {
          containers: e.containers,
          dispatch: e.dispatch,
          zoneId: x,
          autoHeight: !0,
          horizontalGridCells: 12,
          emptyRows: 20,
          minHeight: "300px",
          containerPadding: [20, 20],
          hint: "Drop components into the main area"
        })
      })]
    })]
  });
}
const X = h(Q, {
  [x]: {
    layout: {},
    items: {}
  }
}, x), ee = ["All Items", "Recent", "Favorites", "Archived"];
function te() {
  return /* @__PURE__ */ o(w, {
    children: [/* @__PURE__ */ o("header", {
      style: {
        background: "#fff",
        padding: "28px 32px",
        borderBottom: "1px solid #e8e8e8",
        flexShrink: 0
      },
      children: [/* @__PURE__ */ o("div", {
        style: {
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between"
        },
        children: [/* @__PURE__ */ t("h1", {
          style: {
            margin: 0,
            fontSize: 26,
            fontWeight: 800,
            color: "#1a1a2e"
          },
          children: "Item Collection"
        }), /* @__PURE__ */ t("span", {
          style: {
            background: "#4361ee",
            color: "#fff",
            padding: "4px 14px",
            borderRadius: 20,
            fontSize: 12,
            fontWeight: 600
          },
          children: "12 Items"
        })]
      }), /* @__PURE__ */ t("p", {
        style: {
          fontSize: 14,
          color: "#8c8c8c",
          margin: "8px 0 0"
        },
        children: "Browse, search, and manage your collection of items in one place."
      })]
    }), /* @__PURE__ */ t("div", {
      style: {
        display: "flex",
        gap: 0,
        padding: "0 32px",
        background: "#fff",
        borderBottom: "1px solid #e8e8e8",
        flexShrink: 0
      },
      children: ee.map((e, i) => /* @__PURE__ */ t("div", {
        style: {
          padding: "12px 20px",
          fontSize: 14,
          fontWeight: i === 0 ? 600 : 400,
          color: i === 0 ? "#4361ee" : "#8c8c8c",
          borderBottom: i === 0 ? "2px solid #4361ee" : "2px solid transparent"
        },
        children: e
      }, e))
    })]
  });
}
const y = "main_content";
function ie(e) {
  return /* @__PURE__ */ o("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      width: "100%",
      height: e.autoHeight ? "auto" : "100%",
      minHeight: e.autoHeight ? 600 : void 0,
      background: "#f8f9fc",
      fontFamily: "Inter, system-ui, sans-serif",
      overflow: "hidden"
    },
    children: [/* @__PURE__ */ t(te, {}), /* @__PURE__ */ t("div", {
      style: {
        flex: 1,
        padding: "24px 32px",
        minHeight: 250
      },
      children: /* @__PURE__ */ t("div", {
        style: {
          background: "#fff",
          borderRadius: 12,
          boxShadow: "0 1px 3px rgba(0,0,0,0.06)",
          height: "100%",
          minHeight: 250,
          overflow: "hidden"
        },
        children: /* @__PURE__ */ t(c, {
          containers: e.containers,
          dispatch: e.dispatch,
          zoneId: y,
          autoHeight: !0,
          horizontalGridCells: 12,
          emptyRows: 18,
          minHeight: "250px",
          containerPadding: [16, 16],
          hint: "Drop cards or list components here"
        })
      })
    })]
  });
}
const ne = h(ie, {
  [y]: {
    layout: {},
    items: {}
  }
}, y), oe = [{
  label: "Main",
  items: [{
    icon: "🏠",
    label: "Dashboard",
    active: !0
  }, {
    icon: "📊",
    label: "Analytics"
  }, {
    icon: "👥",
    label: "Users"
  }]
}, {
  label: "Management",
  items: [{
    icon: "📦",
    label: "Products"
  }, {
    icon: "🧾",
    label: "Orders"
  }, {
    icon: "💳",
    label: "Billing"
  }]
}, {
  label: "System",
  items: [{
    icon: "⚙️",
    label: "Settings"
  }, {
    icon: "🔐",
    label: "Security"
  }]
}];
function ae({
  onToggle: e
}) {
  return /* @__PURE__ */ o("header", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      height: 52,
      padding: "0 20px",
      background: "#fff",
      borderBottom: "1px solid #e8e8e8",
      flexShrink: 0
    },
    children: [/* @__PURE__ */ o("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 16
      },
      children: [/* @__PURE__ */ t("button", {
        type: "button",
        onClick: e,
        onMouseDown: (i) => i.stopPropagation(),
        style: {
          width: 32,
          height: 32,
          border: "none",
          borderRadius: 6,
          background: "transparent",
          fontSize: 18,
          cursor: "pointer"
        },
        children: "☰"
      }), /* @__PURE__ */ t("div", {
        style: {
          display: "flex",
          alignItems: "center",
          background: "#f5f6fa",
          borderRadius: 8,
          padding: "6px 14px",
          gap: 8,
          minWidth: 280,
          fontSize: 13,
          color: "#bbb"
        },
        children: "🔍 Search anything..."
      })]
    }), /* @__PURE__ */ o("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 12
      },
      children: [/* @__PURE__ */ t("span", {
        style: {
          fontSize: 16
        },
        children: "🔔"
      }), /* @__PURE__ */ t("span", {
        style: {
          fontSize: 16
        },
        children: "💬"
      }), /* @__PURE__ */ t("div", {
        style: {
          width: 32,
          height: 32,
          borderRadius: "50%",
          background: "#4361ee",
          color: "#fff",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontSize: 13,
          fontWeight: 700
        },
        children: "A"
      })]
    })]
  });
}
function re({
  collapsed: e
}) {
  return /* @__PURE__ */ t("aside", {
    style: {
      width: e ? 60 : 220,
      background: "#fafbfc",
      borderRight: "1px solid #e8e8e8",
      flexShrink: 0,
      paddingTop: 8,
      overflow: "hidden",
      transition: "width 0.2s ease"
    },
    children: oe.map((i) => /* @__PURE__ */ o("div", {
      style: {
        marginBottom: 16
      },
      children: [/* @__PURE__ */ t("div", {
        style: {
          fontSize: 10,
          textTransform: "uppercase",
          letterSpacing: 1,
          color: "#aaa",
          padding: e ? "8px 12px" : "8px 16px"
        },
        children: e ? "•" : i.label
      }), i.items.map((n) => /* @__PURE__ */ o("div", {
        style: {
          display: "flex",
          alignItems: "center",
          gap: 10,
          padding: e ? "9px 19px" : "9px 16px",
          margin: "1px 6px",
          borderRadius: 6,
          fontSize: 13,
          color: n.active ? "#4361ee" : "#555",
          background: n.active ? "rgba(67,97,238,0.07)" : "transparent",
          fontWeight: n.active ? 600 : 400
        },
        children: [/* @__PURE__ */ t("span", {
          style: {
            width: 20,
            textAlign: "center"
          },
          children: n.icon
        }), !e && n.label]
      }, n.label))]
    }, i.label))
  });
}
const b = "main_content";
function le(e) {
  const [i, n] = $react.useState(!1);
  return /* @__PURE__ */ o("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      width: "100%",
      height: e.autoHeight ? "auto" : "100%",
      minHeight: e.autoHeight ? 680 : void 0,
      fontFamily: "Inter, system-ui, sans-serif",
      overflow: "hidden"
    },
    children: [/* @__PURE__ */ t(ae, {
      onToggle: () => n(!i)
    }), /* @__PURE__ */ o("div", {
      style: {
        display: "flex",
        flex: 1,
        minHeight: 0
      },
      children: [/* @__PURE__ */ t(re, {
        collapsed: i
      }), /* @__PURE__ */ o("main", {
        style: {
          flex: 1,
          minWidth: 0,
          display: "flex",
          flexDirection: "column",
          background: "#f0f2f5"
        },
        children: [/* @__PURE__ */ o("div", {
          style: {
            padding: "18px 24px",
            fontSize: 13,
            color: "#999"
          },
          children: ["Admin / ", /* @__PURE__ */ t("strong", {
            style: {
              color: "#333"
            },
            children: "Dashboard"
          })]
        }), /* @__PURE__ */ t("div", {
          style: {
            flex: 1,
            padding: "0 24px 24px",
            minHeight: 300
          },
          children: /* @__PURE__ */ t("div", {
            style: {
              background: "#fff",
              borderRadius: 10,
              boxShadow: "0 1px 3px rgba(0,0,0,0.04)",
              height: "100%",
              minHeight: 300,
              overflow: "hidden"
            },
            children: /* @__PURE__ */ t(c, {
              containers: e.containers,
              dispatch: e.dispatch,
              zoneId: b,
              autoHeight: !0,
              horizontalGridCells: 12,
              emptyRows: 20,
              minHeight: "300px",
              containerPadding: [16, 16],
              hint: "Drop admin widgets here"
            })
          })
        })]
      })]
    })]
  });
}
const de = h(le, {
  [b]: {
    layout: {},
    items: {}
  }
}, b), ce = {
  dashboardTemplate: L,
  landingPageTemplate: q,
  sidebarTemplate: X,
  cardGridTemplate: ne,
  adminPanelTemplate: de
};
export {
  ce as default
};
