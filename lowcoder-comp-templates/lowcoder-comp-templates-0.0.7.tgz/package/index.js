(function(){"use strict";try{if(typeof document!="undefined"){var e=document.createElement("style");e.id="lowcoder-comp-templates-0.0.7",e.appendChild(document.createTextNode("")),document.head.appendChild(e)}}catch(c){console.error("vite-plugin-css-injected-by-js",c)}})();
var V = Object.defineProperty, v = Object.defineProperties;
var z = Object.getOwnPropertyDescriptors;
var k = Object.getOwnPropertySymbols;
var P = Object.prototype.hasOwnProperty, D = Object.prototype.propertyIsEnumerable;
var $ = (e, t, o) => t in e ? V(e, t, { enumerable: !0, configurable: !0, writable: !0, value: o }) : e[t] = o, c = (e, t) => {
  for (var o in t || (t = {}))
    P.call(t, o) && $(e, o, t[o]);
  if (k)
    for (var o of k(t))
      D.call(t, o) && $(e, o, t[o]);
  return e;
}, u = (e, t) => v(e, z(t));
var p = { exports: {} }, g = {};
const G = $react;
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var I = G, R = Symbol.for("react.element"), N = Symbol.for("react.fragment"), L = Object.prototype.hasOwnProperty, B = I.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner, W = { key: !0, ref: !0, __self: !0, __source: !0 };
function x(e, t, o) {
  var n, l = {}, h = null, f = null;
  o !== void 0 && (h = "" + o), t.key !== void 0 && (h = "" + t.key), t.ref !== void 0 && (f = t.ref);
  for (n in t)
    L.call(t, n) && !W.hasOwnProperty(n) && (l[n] = t[n]);
  if (e && e.defaultProps)
    for (n in t = e.defaultProps, t)
      l[n] === void 0 && (l[n] = t[n]);
  return { $$typeof: R, type: e, key: h, ref: f, props: l, _owner: B.current };
}
g.Fragment = N;
g.jsx = x;
g.jsxs = x;
p.exports = g;
var w = p.exports;
const m = w.Fragment, i = w.jsx, d = w.jsxs;
function a(e) {
  var l, h;
  const t = (l = e.containers[e.zoneId]) == null ? void 0 : l.children;
  if (!t)
    return null;
  const o = e.hint ? /* @__PURE__ */ i($lowcoder_sdk.ContainerPlaceholder, {
    children: e.hint
  }) : $lowcoder_sdk.HintPlaceHolder, n = /* @__PURE__ */ i($lowcoder_sdk.InnerGrid, {
    layout: t.layout.getView(),
    items: $lowcoder_sdk.gridItemCompToGridItems(t.items.getView()),
    positionParams: t.positionParams.getView(),
    dispatch: $lowcoder_sdk.wrapDispatch($lowcoder_sdk.wrapDispatch(e.dispatch, "containers"), e.zoneId),
    autoHeight: e.autoHeight,
    horizontalGridCells: e.horizontalGridCells,
    emptyRows: (h = e.emptyRows) != null ? h : 15,
    minHeight: e.minHeight,
    containerPadding: e.containerPadding,
    hintPlaceholder: o,
    showName: e.showName,
    overflow: e.overflow
  });
  return e.autoHeight ? /* @__PURE__ */ i("div", {
    style: {
      minHeight: e.minHeight,
      width: "100%"
    },
    children: n
  }) : /* @__PURE__ */ i($lowcoder_sdk.ScrollBar, {
    style: {
      height: "100%",
      minHeight: e.minHeight,
      margin: "0px",
      padding: "0px"
    },
    hideScrollbar: !e.showScrollbar,
    overflow: "scroll",
    children: n
  });
}
function b(e) {
  var o;
  const t = e.styleConfig || {};
  return /* @__PURE__ */ i("div", {
    style: {
      display: "flex",
      flexDirection: (o = e.direction) != null ? o : "column",
      width: "100%",
      height: e.autoHeight ? "auto" : "100%",
      minHeight: e.autoHeight ? "240px" : void 0,
      overflow: "hidden",
      background: t.background || "transparent",
      borderRadius: t.radius || "4px",
      borderWidth: t.borderWidth || "1px",
      borderStyle: t.borderStyle || "solid",
      borderColor: t.border || "#d7d9e0",
      padding: t.padding || "0px",
      margin: t.margin || "0px"
    },
    children: e.children
  });
}
function s(e) {
  const t = {
    borderBottom: e.border === "bottom" ? "1px solid #d7d9e0" : void 0,
    borderRight: e.border === "right" ? "1px solid #d7d9e0" : void 0,
    borderTop: e.border === "top" ? "1px solid #d7d9e0" : void 0,
    borderLeft: e.border === "left" ? "1px solid #d7d9e0" : void 0
  };
  return /* @__PURE__ */ i("div", {
    style: u(c({}, t), {
      position: "relative",
      flex: e.flex,
      flexShrink: e.width || e.height ? 0 : void 0,
      width: typeof e.width == "number" ? `${e.width}px` : e.width,
      height: typeof e.height == "number" ? `${e.height}px` : e.height,
      minHeight: e.minHeight,
      minWidth: e.minWidth,
      overflow: e.overflow || "hidden",
      background: e.background || "transparent"
    }),
    children: e.children
  });
}
const j = {
  templates: {
    appShell: "App Shell Layout",
    dashboard: "Dashboard Layout",
    chat: "Chat Layout"
  },
  sections: {
    layout: "Layout",
    style: "Style",
    regions: "Regions"
  },
  props: {
    autoHeight: "Auto height",
    showScrollbars: "Show scrollbars",
    horizontalGridCells: "Horizontal grid cells",
    headerHeight: "Header height",
    sidebarWidth: "Sidebar width",
    metricHeight: "Metric row height",
    composerHeight: "Composer height"
  },
  hints: {
    header: "Drop zone: header controls",
    sidebar: "Drop zone: navigation or filters",
    content: "Drop zone: main content",
    metrics: "Drop zone: KPI cards",
    body: "Drop zone: dashboard content",
    messages: "Drop zone: chat thread content",
    composer: "Drop zone: composer controls"
  }
}, O = {
  templates: {
    appShell: "应用外壳布局",
    dashboard: "仪表盘布局",
    chat: "聊天布局"
  },
  sections: {
    layout: "布局",
    style: "样式",
    regions: "区域"
  },
  props: {
    autoHeight: "自动高度",
    showScrollbars: "显示滚动条",
    horizontalGridCells: "水平网格列数",
    headerHeight: "页头高度",
    sidebarWidth: "侧边栏宽度",
    metricHeight: "指标行高度",
    composerHeight: "输入区高度"
  },
  hints: {
    header: "投放区域：页头控件",
    sidebar: "投放区域：导航或筛选控件",
    content: "投放区域：主要内容",
    metrics: "投放区域：指标卡片",
    body: "投放区域：仪表盘内容",
    messages: "投放区域：聊天内容",
    composer: "投放区域：输入控件"
  }
}, S = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  en: j,
  zh: O
}, Symbol.toStringTag, { value: "Module" })), {
  trans: r,
  language: ie
} = new $lowcoder_sdk.Translator(S, "");
$lowcoder_sdk.getI18nObjects(S, "");
function y(e, t, o) {
  var n;
  return o == null ? (n = e[t]) != null ? n : Object.values(e)[0] : Object.values(e).find((l) => l.realSimpleContainer(o));
}
function C(e) {
  return $lowcoder_sdk.mergeCompTrees(Object.values(e).map((t) => t.getCompTree()));
}
function H(e, t, o) {
  for (const n of Object.values(t)) {
    const l = n.findContainer(o);
    if (l)
      return l === n ? e : l;
  }
}
function _(e, t, o) {
  const n = {};
  return Object.keys(t).forEach((l) => {
    n[l] = t[l].getPasteValue(o);
  }), u(c({}, e), { containers: n });
}
const T = {
  headerHeight: $lowcoder_sdk.withDefault($lowcoder_sdk.NumberControl, 72),
  sidebarWidth: $lowcoder_sdk.withDefault($lowcoder_sdk.NumberControl, 260),
  horizontalGridCells: $lowcoder_sdk.withDefault($lowcoder_sdk.NumberControl, 24),
  autoHeight: $lowcoder_sdk.AutoHeightControl,
  showScrollbars: $lowcoder_sdk.withDefault($lowcoder_sdk.BoolControl, !1),
  style: $lowcoder_sdk.styleControl($lowcoder_sdk.ContainerStyle),
  containers: $lowcoder_sdk.withDefault($lowcoder_sdk.sameTypeMap($lowcoder_sdk.SimpleContainerComp), {
    header: {
      layout: {},
      items: {}
    },
    sidebar: {
      layout: {},
      items: {}
    },
    content: {
      layout: {},
      items: {}
    }
  })
}, E = (e) => {
  var o;
  const t = $react.useContext($lowcoder_sdk.BackgroundColorContext);
  return /* @__PURE__ */ i($lowcoder_sdk.BackgroundColorContext.Provider, {
    value: ((o = e.style) == null ? void 0 : o.background) || t,
    children: /* @__PURE__ */ d(b, {
      styleConfig: e.style,
      autoHeight: e.autoHeight,
      children: [/* @__PURE__ */ i(s, {
        height: e.headerHeight,
        minHeight: 64,
        border: "bottom",
        overflow: "visible",
        children: /* @__PURE__ */ i(a, {
          containers: e.containers,
          dispatch: e.dispatch,
          zoneId: "header",
          autoHeight: !0,
          horizontalGridCells: e.horizontalGridCells,
          emptyRows: 5,
          minHeight: "64px",
          containerPadding: [0, 0],
          hint: r("hints.header"),
          showName: {
            bottom: 12
          }
        })
      }), /* @__PURE__ */ d("div", {
        style: {
          display: "flex",
          flex: 1,
          minHeight: e.autoHeight ? 220 : void 0
        },
        children: [/* @__PURE__ */ i(s, {
          width: e.sidebarWidth,
          minWidth: 180,
          border: "right",
          children: /* @__PURE__ */ i(a, {
            containers: e.containers,
            dispatch: e.dispatch,
            zoneId: "sidebar",
            autoHeight: !0,
            horizontalGridCells: 12,
            emptyRows: 30,
            minHeight: "360px",
            containerPadding: [0, 0],
            hint: r("hints.sidebar")
          })
        }), /* @__PURE__ */ i(s, {
          flex: 1,
          minHeight: e.autoHeight ? 220 : void 0,
          children: /* @__PURE__ */ i(a, {
            containers: e.containers,
            dispatch: e.dispatch,
            zoneId: "content",
            autoHeight: e.autoHeight,
            showScrollbar: e.showScrollbars,
            horizontalGridCells: e.horizontalGridCells,
            emptyRows: 20,
            minHeight: "260px",
            containerPadding: [0, 0],
            hint: r("hints.content")
          })
        })]
      })]
    })
  });
}, A = new $lowcoder_sdk.UICompBuilder(T, (e, t) => /* @__PURE__ */ i(E, u(c({}, e), {
  dispatch: t
}))).setPropertyViewFn((e) => /* @__PURE__ */ d(m, {
  children: [/* @__PURE__ */ d($lowcoder_sdk.Section, {
    name: r("sections.layout"),
    children: [e.headerHeight.propertyView({
      label: r("props.headerHeight")
    }), e.sidebarWidth.propertyView({
      label: r("props.sidebarWidth")
    }), e.horizontalGridCells.propertyView({
      label: r("props.horizontalGridCells")
    }), e.autoHeight.getPropertyView(), !e.autoHeight.getView() && e.showScrollbars.propertyView({
      label: r("props.showScrollbars")
    })]
  }), /* @__PURE__ */ i($lowcoder_sdk.Section, {
    name: r("sections.style"),
    children: e.style.getPropertyView()
  })]
})).build();
class M extends A {
  realSimpleContainer(t) {
    return y(this.children.containers.children, "content", t);
  }
  getCompTree() {
    return C(this.children.containers.getView());
  }
  findContainer(t) {
    return H(this, this.children.containers.getView(), t);
  }
  getPasteValue(t) {
    return _(this.toJsonValue(), this.children.containers.getView(), t);
  }
  autoHeight() {
    return this.children.autoHeight.getView();
  }
}
const F = $lowcoder_sdk.withExposingConfigs(M, [$lowcoder_sdk.NameConfigHidden]), U = {
  sidebarWidth: $lowcoder_sdk.withDefault($lowcoder_sdk.NumberControl, 300),
  composerHeight: $lowcoder_sdk.withDefault($lowcoder_sdk.NumberControl, 96),
  horizontalGridCells: $lowcoder_sdk.withDefault($lowcoder_sdk.NumberControl, 24),
  autoHeight: $lowcoder_sdk.AutoHeightControl,
  showScrollbars: $lowcoder_sdk.withDefault($lowcoder_sdk.BoolControl, !1),
  style: $lowcoder_sdk.styleControl($lowcoder_sdk.ContainerStyle),
  containers: $lowcoder_sdk.withDefault($lowcoder_sdk.sameTypeMap($lowcoder_sdk.SimpleContainerComp), {
    sidebar: {
      layout: {},
      items: {}
    },
    messages: {
      layout: {},
      items: {}
    },
    composer: {
      layout: {},
      items: {}
    }
  })
}, J = (e) => {
  var o;
  const t = $react.useContext($lowcoder_sdk.BackgroundColorContext);
  return /* @__PURE__ */ i($lowcoder_sdk.BackgroundColorContext.Provider, {
    value: ((o = e.style) == null ? void 0 : o.background) || t,
    children: /* @__PURE__ */ d(b, {
      styleConfig: e.style,
      autoHeight: e.autoHeight,
      direction: "row",
      children: [/* @__PURE__ */ i(s, {
        width: e.sidebarWidth,
        minWidth: 200,
        border: "right",
        children: /* @__PURE__ */ i(a, {
          containers: e.containers,
          dispatch: e.dispatch,
          zoneId: "sidebar",
          autoHeight: !0,
          horizontalGridCells: 12,
          emptyRows: 30,
          minHeight: "360px",
          containerPadding: [0, 0],
          hint: r("hints.sidebar")
        })
      }), /* @__PURE__ */ d("div", {
        style: {
          display: "flex",
          flex: 1,
          flexDirection: "column",
          minWidth: 0
        },
        children: [/* @__PURE__ */ i(s, {
          flex: 1,
          minHeight: e.autoHeight ? 240 : void 0,
          children: /* @__PURE__ */ i(a, {
            containers: e.containers,
            dispatch: e.dispatch,
            zoneId: "messages",
            autoHeight: e.autoHeight,
            showScrollbar: e.showScrollbars,
            horizontalGridCells: e.horizontalGridCells,
            emptyRows: 22,
            minHeight: "280px",
            containerPadding: [0, 0],
            hint: r("hints.messages")
          })
        }), /* @__PURE__ */ i(s, {
          height: e.composerHeight,
          minHeight: 88,
          border: "top",
          overflow: "visible",
          children: /* @__PURE__ */ i(a, {
            containers: e.containers,
            dispatch: e.dispatch,
            zoneId: "composer",
            autoHeight: !0,
            horizontalGridCells: e.horizontalGridCells,
            emptyRows: 8,
            minHeight: "88px",
            containerPadding: [0, 0],
            hint: r("hints.composer"),
            showName: {
              top: 12
            }
          })
        })]
      })]
    })
  });
}, q = new $lowcoder_sdk.UICompBuilder(U, (e, t) => /* @__PURE__ */ i(J, u(c({}, e), {
  dispatch: t
}))).setPropertyViewFn((e) => /* @__PURE__ */ d(m, {
  children: [/* @__PURE__ */ d($lowcoder_sdk.Section, {
    name: r("sections.layout"),
    children: [e.sidebarWidth.propertyView({
      label: r("props.sidebarWidth")
    }), e.composerHeight.propertyView({
      label: r("props.composerHeight")
    }), e.horizontalGridCells.propertyView({
      label: r("props.horizontalGridCells")
    }), e.autoHeight.getPropertyView(), !e.autoHeight.getView() && e.showScrollbars.propertyView({
      label: r("props.showScrollbars")
    })]
  }), /* @__PURE__ */ i($lowcoder_sdk.Section, {
    name: r("sections.style"),
    children: e.style.getPropertyView()
  })]
})).build();
class K extends q {
  realSimpleContainer(t) {
    return y(this.children.containers.children, "messages", t);
  }
  getCompTree() {
    return C(this.children.containers.getView());
  }
  findContainer(t) {
    return H(this, this.children.containers.getView(), t);
  }
  getPasteValue(t) {
    return _(this.toJsonValue(), this.children.containers.getView(), t);
  }
  autoHeight() {
    return this.children.autoHeight.getView();
  }
}
const Y = $lowcoder_sdk.withExposingConfigs(K, [$lowcoder_sdk.NameConfigHidden]), Z = {
  headerHeight: $lowcoder_sdk.withDefault($lowcoder_sdk.NumberControl, 80),
  metricHeight: $lowcoder_sdk.withDefault($lowcoder_sdk.NumberControl, 112),
  horizontalGridCells: $lowcoder_sdk.withDefault($lowcoder_sdk.NumberControl, 24),
  autoHeight: $lowcoder_sdk.AutoHeightControl,
  showScrollbars: $lowcoder_sdk.withDefault($lowcoder_sdk.BoolControl, !1),
  style: $lowcoder_sdk.styleControl($lowcoder_sdk.ContainerStyle),
  containers: $lowcoder_sdk.withDefault($lowcoder_sdk.sameTypeMap($lowcoder_sdk.SimpleContainerComp), {
    header: {
      layout: {},
      items: {}
    },
    metrics: {
      layout: {},
      items: {}
    },
    content: {
      layout: {},
      items: {}
    }
  })
}, Q = (e) => {
  var o;
  const t = $react.useContext($lowcoder_sdk.BackgroundColorContext);
  return /* @__PURE__ */ i($lowcoder_sdk.BackgroundColorContext.Provider, {
    value: ((o = e.style) == null ? void 0 : o.background) || t,
    children: /* @__PURE__ */ d(b, {
      styleConfig: e.style,
      autoHeight: e.autoHeight,
      children: [/* @__PURE__ */ i(s, {
        height: e.headerHeight,
        minHeight: 72,
        border: "bottom",
        overflow: "visible",
        children: /* @__PURE__ */ i(a, {
          containers: e.containers,
          dispatch: e.dispatch,
          zoneId: "header",
          autoHeight: !0,
          horizontalGridCells: e.horizontalGridCells,
          emptyRows: 6,
          minHeight: "72px",
          containerPadding: [0, 0],
          hint: r("hints.header"),
          showName: {
            bottom: 12
          }
        })
      }), /* @__PURE__ */ i(s, {
        height: e.metricHeight,
        minHeight: 80,
        border: "bottom",
        children: /* @__PURE__ */ i(a, {
          containers: e.containers,
          dispatch: e.dispatch,
          zoneId: "metrics",
          autoHeight: !0,
          horizontalGridCells: e.horizontalGridCells,
          emptyRows: 10,
          minHeight: "80px",
          containerPadding: [0, 0],
          hint: r("hints.metrics"),
          showName: {
            bottom: 12
          }
        })
      }), /* @__PURE__ */ i(s, {
        flex: 1,
        minHeight: e.autoHeight ? 180 : void 0,
        children: /* @__PURE__ */ i(a, {
          containers: e.containers,
          dispatch: e.dispatch,
          zoneId: "content",
          autoHeight: e.autoHeight,
          showScrollbar: e.showScrollbars,
          horizontalGridCells: e.horizontalGridCells,
          emptyRows: 18,
          minHeight: "260px",
          containerPadding: [0, 0],
          hint: r("hints.body")
        })
      })]
    })
  });
}, X = new $lowcoder_sdk.UICompBuilder(Z, (e, t) => /* @__PURE__ */ i(Q, u(c({}, e), {
  dispatch: t
}))).setPropertyViewFn((e) => /* @__PURE__ */ d(m, {
  children: [/* @__PURE__ */ d($lowcoder_sdk.Section, {
    name: r("sections.layout"),
    children: [e.headerHeight.propertyView({
      label: r("props.headerHeight")
    }), e.metricHeight.propertyView({
      label: r("props.metricHeight")
    }), e.horizontalGridCells.propertyView({
      label: r("props.horizontalGridCells")
    }), e.autoHeight.getPropertyView(), !e.autoHeight.getView() && e.showScrollbars.propertyView({
      label: r("props.showScrollbars")
    })]
  }), /* @__PURE__ */ i($lowcoder_sdk.Section, {
    name: r("sections.style"),
    children: e.style.getPropertyView()
  })]
})).build();
class ee extends X {
  realSimpleContainer(t) {
    return y(this.children.containers.children, "content", t);
  }
  getCompTree() {
    return C(this.children.containers.getView());
  }
  findContainer(t) {
    return H(this, this.children.containers.getView(), t);
  }
  getPasteValue(t) {
    return _(this.toJsonValue(), this.children.containers.getView(), t);
  }
  autoHeight() {
    return this.children.autoHeight.getView();
  }
}
const te = $lowcoder_sdk.withExposingConfigs(ee, [$lowcoder_sdk.NameConfigHidden]), re = {
  app_shell_layout: F,
  dashboard_layout: te,
  chat_layout: Y
};
export {
  re as default
};
