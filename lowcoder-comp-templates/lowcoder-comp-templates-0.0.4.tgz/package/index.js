(function(){"use strict";try{if(typeof document!="undefined"){var e=document.createElement("style");e.id="lowcoder-comp-templates-0.0.4",e.appendChild(document.createTextNode("")),document.head.appendChild(e)}}catch(c){console.error("vite-plugin-css-injected-by-js",c)}})();
var v = Object.defineProperty, V = Object.defineProperties;
var P = Object.getOwnPropertyDescriptors;
var k = Object.getOwnPropertySymbols;
var H = Object.prototype.hasOwnProperty, S = Object.prototype.propertyIsEnumerable;
var C = (e, t, o) => t in e ? v(e, t, { enumerable: !0, configurable: !0, writable: !0, value: o }) : e[t] = o, a = (e, t) => {
  for (var o in t || (t = {}))
    H.call(t, o) && C(e, o, t[o]);
  if (k)
    for (var o of k(t))
      S.call(t, o) && C(e, o, t[o]);
  return e;
}, c = (e, t) => V(e, P(t));
var $ = { exports: {} }, y = {};
const D = $react;
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var T = D, j = Symbol.for("react.element"), O = Symbol.for("react.fragment"), R = Object.prototype.hasOwnProperty, M = T.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner, L = { key: !0, ref: !0, __self: !0, __source: !0 };
function b(e, t, o) {
  var r, n = {}, l = null, d = null;
  o !== void 0 && (l = "" + o), t.key !== void 0 && (l = "" + t.key), t.ref !== void 0 && (d = t.ref);
  for (r in t)
    R.call(t, r) && !L.hasOwnProperty(r) && (n[r] = t[r]);
  if (e && e.defaultProps)
    for (r in t = e.defaultProps, t)
      n[r] === void 0 && (n[r] = t[r]);
  return { $$typeof: j, type: e, key: l, ref: d, props: n, _owner: M.current };
}
y.Fragment = O;
y.jsx = b;
y.jsxs = b;
$.exports = y;
var _ = $.exports;
const x = _.Fragment, i = _.jsx, u = _.jsxs, E = {
  leftRatio: $lowcoder_sdk.withDefault($lowcoder_sdk.NumberControl, 50),
  autoHeight: $lowcoder_sdk.AutoHeightControl,
  style: $lowcoder_sdk.styleControl($lowcoder_sdk.ContainerStyle),
  containers: $lowcoder_sdk.withDefault($lowcoder_sdk.sameTypeMap($lowcoder_sdk.SimpleContainerComp), {
    left: {
      layout: {},
      items: {}
    },
    right: {
      layout: {},
      items: {}
    }
  })
}, B = (e) => /* @__PURE__ */ i($lowcoder_sdk.InnerGrid, c(a({}, e), {
  emptyRows: 15,
  hintPlaceholder: $lowcoder_sdk.HintPlaceHolder,
  enableGridLines: !0
})), I = (e) => {
  var n, l, d, m, p, h;
  const t = $react.useContext($lowcoder_sdk.BackgroundColorContext), o = Math.max(10, Math.min(90, e.leftRatio)), r = (s) => {
    var f;
    const w = (f = e.containers[s]) == null ? void 0 : f.children;
    if (!w)
      return null;
    const g = $lowcoder_sdk.wrapDispatch($lowcoder_sdk.wrapDispatch(e.dispatch, "containers"), s);
    return /* @__PURE__ */ i(B, {
      layout: w.layout.getView(),
      items: $lowcoder_sdk.gridItemCompToGridItems(w.items.getView()),
      positionParams: w.positionParams.getView(),
      dispatch: g,
      autoHeight: e.autoHeight
    });
  };
  return /* @__PURE__ */ i($lowcoder_sdk.BackgroundColorContext.Provider, {
    value: ((n = e.style) == null ? void 0 : n.background) || t,
    children: /* @__PURE__ */ u("div", {
      style: {
        display: "flex",
        height: "100%",
        width: "100%",
        gap: "0px",
        backgroundColor: ((l = e.style) == null ? void 0 : l.background) || "transparent",
        borderRadius: ((d = e.style) == null ? void 0 : d.radius) || "4px",
        border: (m = e.style) != null && m.border ? `${((p = e.style) == null ? void 0 : p.borderWidth) || "1px"} solid ${(h = e.style) == null ? void 0 : h.border}` : "1px solid #e1e3eb",
        overflow: "hidden"
      },
      children: [/* @__PURE__ */ i("div", {
        style: {
          width: `${o}%`,
          position: "relative",
          overflow: "hidden"
        },
        children: r("left")
      }), /* @__PURE__ */ i("div", {
        style: {
          width: "1px",
          backgroundColor: "#e1e3eb",
          flexShrink: 0
        }
      }), /* @__PURE__ */ i("div", {
        style: {
          width: `${100 - o}%`,
          position: "relative",
          overflow: "hidden"
        },
        children: r("right")
      })]
    })
  });
}, N = new $lowcoder_sdk.UICompBuilder(E, (e, t) => /* @__PURE__ */ i(I, c(a({}, e), {
  dispatch: t
}))).setPropertyViewFn((e) => /* @__PURE__ */ u(x, {
  children: [/* @__PURE__ */ u($lowcoder_sdk.Section, {
    name: "Layout",
    children: [e.leftRatio.propertyView({
      label: "Left Column Width (%)",
      tooltip: "Width of the left column as a percentage (10-90)"
    }), e.autoHeight.getPropertyView()]
  }), /* @__PURE__ */ i($lowcoder_sdk.Section, {
    name: "Style",
    children: e.style.getPropertyView()
  })]
})).build();
class F extends N {
  realSimpleContainer(t) {
    return Object.values(this.children.containers.children).find((o) => o.realSimpleContainer(t));
  }
  getCompTree() {
    const t = this.children.containers.getView(), o = Object.values(t).map((r) => r.getCompTree());
    return $lowcoder_sdk.mergeCompTrees(o);
  }
  findContainer(t) {
    const o = this.children.containers.getView();
    for (const r of Object.values(o)) {
      const n = r.findContainer(t);
      if (n)
        return n === r ? this : n;
    }
  }
  getPasteValue(t) {
    const o = this.children.containers.getView(), r = {};
    return Object.keys(o).forEach((n) => {
      r[n] = o[n].getPasteValue(t);
    }), c(a({}, this.toJsonValue()), {
      containers: r
    });
  }
  autoHeight() {
    return this.children.autoHeight.getView();
  }
}
const G = $lowcoder_sdk.withExposingConfigs(F, [$lowcoder_sdk.NameConfigHidden]), W = {
  title: $lowcoder_sdk.withDefault($lowcoder_sdk.StringControl, "Dashboard"),
  headerHeight: $lowcoder_sdk.withDefault($lowcoder_sdk.NumberControl, 80),
  autoHeight: $lowcoder_sdk.AutoHeightControl,
  style: $lowcoder_sdk.styleControl($lowcoder_sdk.ContainerStyle),
  containers: $lowcoder_sdk.withDefault($lowcoder_sdk.sameTypeMap($lowcoder_sdk.SimpleContainerComp), {
    header: {
      layout: {},
      items: {}
    },
    body: {
      layout: {},
      items: {}
    }
  })
}, U = (e) => /* @__PURE__ */ i($lowcoder_sdk.InnerGrid, c(a({}, e), {
  emptyRows: 15,
  hintPlaceholder: $lowcoder_sdk.HintPlaceHolder,
  enableGridLines: !0
})), A = (e) => {
  var r, n, l, d, m, p;
  const t = $react.useContext($lowcoder_sdk.BackgroundColorContext), o = (h) => {
    var g;
    const s = (g = e.containers[h]) == null ? void 0 : g.children;
    if (!s)
      return null;
    const w = $lowcoder_sdk.wrapDispatch($lowcoder_sdk.wrapDispatch(e.dispatch, "containers"), h);
    return /* @__PURE__ */ i(U, {
      layout: s.layout.getView(),
      items: $lowcoder_sdk.gridItemCompToGridItems(s.items.getView()),
      positionParams: s.positionParams.getView(),
      dispatch: w,
      autoHeight: h === "header"
    });
  };
  return /* @__PURE__ */ i($lowcoder_sdk.BackgroundColorContext.Provider, {
    value: ((r = e.style) == null ? void 0 : r.background) || t,
    children: /* @__PURE__ */ u("div", {
      style: {
        display: "flex",
        flexDirection: "column",
        height: "100%",
        width: "100%",
        backgroundColor: ((n = e.style) == null ? void 0 : n.background) || "transparent",
        borderRadius: ((l = e.style) == null ? void 0 : l.radius) || "4px",
        border: (d = e.style) != null && d.border ? `${((m = e.style) == null ? void 0 : m.borderWidth) || "1px"} solid ${(p = e.style) == null ? void 0 : p.border}` : "1px solid #e1e3eb",
        overflow: "hidden"
      },
      children: [/* @__PURE__ */ u("div", {
        style: {
          minHeight: `${e.headerHeight}px`,
          borderBottom: "1px solid #e1e3eb",
          position: "relative",
          flexShrink: 0
        },
        children: [e.title && /* @__PURE__ */ i("div", {
          style: {
            padding: "8px 12px 0",
            fontSize: "16px",
            fontWeight: 600,
            color: "#222"
          },
          children: e.title
        }), o("header")]
      }), /* @__PURE__ */ i("div", {
        style: {
          flex: 1,
          position: "relative",
          overflow: "hidden"
        },
        children: o("body")
      })]
    })
  });
}, J = new $lowcoder_sdk.UICompBuilder(W, (e, t) => /* @__PURE__ */ i(A, c(a({}, e), {
  dispatch: t
}))).setPropertyViewFn((e) => /* @__PURE__ */ u(x, {
  children: [/* @__PURE__ */ i($lowcoder_sdk.Section, {
    name: "Content",
    children: e.title.propertyView({
      label: "Title"
    })
  }), /* @__PURE__ */ u($lowcoder_sdk.Section, {
    name: "Layout",
    children: [e.headerHeight.propertyView({
      label: "Header Height (px)",
      tooltip: "Minimum height of the header zone in pixels"
    }), e.autoHeight.getPropertyView()]
  }), /* @__PURE__ */ i($lowcoder_sdk.Section, {
    name: "Style",
    children: e.style.getPropertyView()
  })]
})).build();
class Z extends J {
  realSimpleContainer(t) {
    return Object.values(this.children.containers.children).find((o) => o.realSimpleContainer(t));
  }
  getCompTree() {
    const t = this.children.containers.getView(), o = Object.values(t).map((r) => r.getCompTree());
    return $lowcoder_sdk.mergeCompTrees(o);
  }
  findContainer(t) {
    const o = this.children.containers.getView();
    for (const r of Object.values(o)) {
      const n = r.findContainer(t);
      if (n)
        return n === r ? this : n;
    }
  }
  getPasteValue(t) {
    const o = this.children.containers.getView(), r = {};
    return Object.keys(o).forEach((n) => {
      r[n] = o[n].getPasteValue(t);
    }), c(a({}, this.toJsonValue()), {
      containers: r
    });
  }
  autoHeight() {
    return this.children.autoHeight.getView();
  }
}
const q = $lowcoder_sdk.withExposingConfigs(Z, [$lowcoder_sdk.NameConfigHidden, new $lowcoder_sdk.NameConfig("title", "Dashboard title text")]), K = {
  two_column_layout: G,
  dashboard_layout: q
};
export {
  K as default
};
